
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/scipts/game/Rocker');
require('./assets/scipts/game/map');
require('./assets/scipts/登录界面/button_game');
require('./assets/scipts/登录界面/button_login');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scipts/登录界面/button_login.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '26024PnwLJO4qKFMqjiWxM4', 'button_login');
// scipts/登录界面/button_login.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
//如果加上了window就相当于声明成了全局变量
window.user_name;
window.user_code;
window.websocket;
var flag_login = 0; //标志变量,告诉客户端是否登录成功
//0失败,1成功

var flag_register = 0; //是否注册成功(如果有重复的用户名将会注册失败)

cc.Class({
  "extends": cc.Component,
  properties: {},
  start: function start() {
    this.initSocket();
  },
  btnClick2: function btnClick2(event, customEventData) {
    user_name = this.node.getChildByName("user_input").getComponent(cc.EditBox).string;
    user_code = this.node.getChildByName("code_input").getComponent(cc.EditBox).string; //websocket.send(user_name.toString()+" "+user_code.toString());

    cc.log(user_name);
    cc.log(user_code);
  }
  /*
      //初始化与服务器建立连接
      initSocket: function(){
          if(window.WebSocket){
              var wsUri = "ws://localhost:8080/tomcat_websocket/test";
              websocket = new WebSocket(wsUri);
              //websocket.binaryType = "arraybuffer";
              //var mythis = this;
              //连接到服务器后执行
              websocket.onopen = function(event) {
                  console.log("connect");
                  //mythis.requestInitInfoBar();
              };
      
              //断开服务器连接后执行
              websocket.onclose = function(event) {
                  console.log("closed");
              };
      
              //接收服务器传递的消息后执行
              websocket.onmessage = function(event) {
                  if(event.data.substr(0,2)=='id')
                      cc.log(event.data);
                  //mythis.processData(json);
              };
              //报错时执行
              websocket.onerror = function(event) {
                  console.log("error");
              };
              }
              else{
                  alert("浏览器不支持WebSocket！");
              }
          }
          */

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NpcHRzXFznmbvlvZXnlYzpnaJcXGJ1dHRvbl9sb2dpbi5qcyJdLCJuYW1lcyI6WyJ3aW5kb3ciLCJ1c2VyX25hbWUiLCJ1c2VyX2NvZGUiLCJ3ZWJzb2NrZXQiLCJmbGFnX2xvZ2luIiwiZmxhZ19yZWdpc3RlciIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3RhcnQiLCJpbml0U29ja2V0IiwiYnRuQ2xpY2syIiwiZXZlbnQiLCJjdXN0b21FdmVudERhdGEiLCJub2RlIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJFZGl0Qm94Iiwic3RyaW5nIiwibG9nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0FBLE1BQU0sQ0FBQ0MsU0FBUDtBQUNBRCxNQUFNLENBQUNFLFNBQVA7QUFDQUYsTUFBTSxDQUFDRyxTQUFQO0FBRUEsSUFBSUMsVUFBVSxHQUFDLENBQWYsRUFDQTtBQUNBOztBQUVBLElBQUlDLGFBQWEsR0FBQyxDQUFsQixFQUNBOztBQUVBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsRUFIUDtBQU1MQyxFQUFBQSxLQU5LLG1CQU1FO0FBQ0gsU0FBS0MsVUFBTDtBQUNILEdBUkk7QUFTTEMsRUFBQUEsU0FBUyxFQUFFLG1CQUFVQyxLQUFWLEVBQWlCQyxlQUFqQixFQUFpQztBQUN4Q2IsSUFBQUEsU0FBUyxHQUFDLEtBQUtjLElBQUwsQ0FBVUMsY0FBVixDQUF5QixZQUF6QixFQUF1Q0MsWUFBdkMsQ0FBb0RYLEVBQUUsQ0FBQ1ksT0FBdkQsRUFBZ0VDLE1BQTFFO0FBQ0FqQixJQUFBQSxTQUFTLEdBQUMsS0FBS2EsSUFBTCxDQUFVQyxjQUFWLENBQXlCLFlBQXpCLEVBQXVDQyxZQUF2QyxDQUFvRFgsRUFBRSxDQUFDWSxPQUF2RCxFQUFnRUMsTUFBMUUsQ0FGd0MsQ0FHeEM7O0FBQ0FiLElBQUFBLEVBQUUsQ0FBQ2MsR0FBSCxDQUFPbkIsU0FBUDtBQUNBSyxJQUFBQSxFQUFFLENBQUNjLEdBQUgsQ0FBT2xCLFNBQVA7QUFDSDtBQUdEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5cclxuXHJcbi8v5aaC5p6c5Yqg5LiK5LqGd2luZG935bCx55u45b2T5LqO5aOw5piO5oiQ5LqG5YWo5bGA5Y+Y6YePXHJcbndpbmRvdy51c2VyX25hbWU7XHJcbndpbmRvdy51c2VyX2NvZGU7XHJcbndpbmRvdy53ZWJzb2NrZXQ7XHJcblxyXG52YXIgZmxhZ19sb2dpbj0wO1xyXG4vL+agh+W/l+WPmOmHjyzlkYror4nlrqLmiLfnq6/mmK/lkKbnmbvlvZXmiJDlip9cclxuLy8w5aSx6LSlLDHmiJDlip9cclxuXHJcbnZhciBmbGFnX3JlZ2lzdGVyPTA7XHJcbi8v5piv5ZCm5rOo5YaM5oiQ5YqfKOWmguaenOaciemHjeWkjeeahOeUqOaIt+WQjeWwhuS8muazqOWGjOWksei0pSlcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0KCl7XHJcbiAgICAgICAgdGhpcy5pbml0U29ja2V0KCk7XHJcbiAgICB9LFxyXG4gICAgYnRuQ2xpY2syOiBmdW5jdGlvbiAoZXZlbnQsIGN1c3RvbUV2ZW50RGF0YSl7XHJcbiAgICAgICAgdXNlcl9uYW1lPXRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcInVzZXJfaW5wdXRcIikuZ2V0Q29tcG9uZW50KGNjLkVkaXRCb3gpLnN0cmluZztcclxuICAgICAgICB1c2VyX2NvZGU9dGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiY29kZV9pbnB1dFwiKS5nZXRDb21wb25lbnQoY2MuRWRpdEJveCkuc3RyaW5nO1xyXG4gICAgICAgIC8vd2Vic29ja2V0LnNlbmQodXNlcl9uYW1lLnRvU3RyaW5nKCkrXCIgXCIrdXNlcl9jb2RlLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgIGNjLmxvZyh1c2VyX25hbWUpO1xyXG4gICAgICAgIGNjLmxvZyh1c2VyX2NvZGUpO1xyXG4gICAgfSxcclxuXHJcblxyXG4gICAgLypcclxuICAgICAgICAvL+WIneWni+WMluS4juacjeWKoeWZqOW7uueri+i/nuaOpVxyXG4gICAgICAgIGluaXRTb2NrZXQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIGlmKHdpbmRvdy5XZWJTb2NrZXQpe1xyXG4gICAgICAgICAgICAgICAgdmFyIHdzVXJpID0gXCJ3czovL2xvY2FsaG9zdDo4MDgwL3RvbWNhdF93ZWJzb2NrZXQvdGVzdFwiO1xyXG4gICAgICAgICAgICAgICAgd2Vic29ja2V0ID0gbmV3IFdlYlNvY2tldCh3c1VyaSk7XHJcbiAgICAgICAgICAgICAgICAvL3dlYnNvY2tldC5iaW5hcnlUeXBlID0gXCJhcnJheWJ1ZmZlclwiO1xyXG4gICAgICAgICAgICAgICAgLy92YXIgbXl0aGlzID0gdGhpcztcclxuICAgICAgICAgICAgICAgIC8v6L+e5o6l5Yiw5pyN5Yqh5Zmo5ZCO5omn6KGMXHJcbiAgICAgICAgICAgICAgICB3ZWJzb2NrZXQub25vcGVuID0gZnVuY3Rpb24oZXZlbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImNvbm5lY3RcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9teXRoaXMucmVxdWVzdEluaXRJbmZvQmFyKCk7XHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy/mlq3lvIDmnI3liqHlmajov57mjqXlkI7miafooYxcclxuICAgICAgICAgICAgICAgIHdlYnNvY2tldC5vbmNsb3NlID0gZnVuY3Rpb24oZXZlbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImNsb3NlZFwiKTtcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvL+aOpeaUtuacjeWKoeWZqOS8oOmAkueahOa2iOaBr+WQjuaJp+ihjFxyXG4gICAgICAgICAgICAgICAgd2Vic29ja2V0Lm9ubWVzc2FnZSA9IGZ1bmN0aW9uKGV2ZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoZXZlbnQuZGF0YS5zdWJzdHIoMCwyKT09J2lkJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKGV2ZW50LmRhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vbXl0aGlzLnByb2Nlc3NEYXRhKGpzb24pO1xyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIC8v5oql6ZSZ5pe25omn6KGMXHJcbiAgICAgICAgICAgICAgICB3ZWJzb2NrZXQub25lcnJvciA9IGZ1bmN0aW9uKGV2ZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlcnJvclwiKTtcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICAgICAgICAgIGFsZXJ0KFwi5rWP6KeI5Zmo5LiN5pSv5oyBV2ViU29ja2V077yBXCIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICovXHJcblxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scipts/game/map.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e4036gdTpRPMZtl3m3wQG9N', 'map');
// scipts/game/map.js

"use strict";

var node = new Array(); //填色数组

var Flag = new Array(100); //连通片数目最多为30，否则此处需继续增加值
//第i个联通片是否是领地内的标记，为0则是

var nodeflag_num; //联通片数量的计数

var tileSize; //地图大小

var v_x = 0;
var v_y = 0;
cc.Class({
  "extends": cc.Component,
  properties: {
    Rocker: {
      type: require("Rocker"),
      "default": null
    },
    speed: 100
  },
  // LIFE-CYCLE CALLBACKS:
  start: function start() {
    cc.log("!!!!"); //cc.log(user_name.toString());
    //cc.log(user_code.toString());
  },
  onLoad: function onLoad() {
    console.log("onLoad");
    this.player_now = this.node.getChildByName('player_now'); //获取player_now节点
    //console.log(this.player_now)

    this.loadMap(); //加载地图

    this.timer = 0;
    v_x = 1;
    v_y = 0;
  },
  tryMoveToNewTile: function tryMoveToNewTile(newTile) {
    var mapSize = this.tiledMap.getMapSize(); //超出边界，直接返回

    if (newTile.x < 0 || newTile.x >= mapSize.width) return;
    if (newTile.y < 0 || newTile.y >= mapSize.height) return; //console.log(this.ground.getTileGIDAt(newTile))
    //1是填充块,2是非填充块
    //this.ground.setTileGIDAt(1,newTile.x,newTile.y)

    if (this.ground.getTileGIDAt(newTile) == 1) //如果当前位置与已填充块重叠，尝试圈地
      this.tryenclosure(); //尝试圈地

    this.playerTile = newTile;
    this.updatePlayerPos();
  },
  tryenclosure: function tryenclosure() {
    //console.log("try to enclosure")
    //var Node_A = new Array();
    nodeflag_num = 1; //联通片数量的计数

    for (var i = 0; i < tileSize.height; i++) {
      node[i] = new Array();

      for (var j = 0; j < tileSize.width; j++) {
        node[i][j] = new Array();

        for (var k = 0; k < 3; k++) {
          node[i][j][k] = new Array();
        }
      }
    } //相当于是Node_A[height][width][3]
    //Node_A[height][width][0]标识该点是填充块还是非填充块
    //[1]标识该点是哪一个联通片


    for (var i = 0; i < 100; i++) {
      Flag[i] = 0;
    } //获取整个地图的填色信息


    for (var i = 0; i < tileSize.height; i++) {
      for (var j = 0; j < tileSize.width; j++) {
        node[i][j][0] = 0;
        node[i][j][1] = 0;
        if (this.ground.getTileGIDAt(i, j) == 1) node[i][j][0] = 1;
      }
    } //深度优先搜索尝试填充
    //分别从上下左右搜寻，进行深度优先搜索


    for (var i = 0; i < tileSize.height; i++) {
      for (var j = 0; j < tileSize.width; j++) {
        //console.log(i+" "+j+"node"+node[i][j][0])
        if (node[i][j][0] == 0 && node[i][j][1] == 0) {
          //console.log(i+"@@@")
          //若未涂实色且不属于之前任何联通片，从此点搜索新联通片
          this.dfs(i, j);
          nodeflag_num = nodeflag_num + 1;
        }
      }
    } //console.log("!")
    //将所有闭联通片涂实


    for (var i = 0; i < tileSize.height; i++) {
      for (var j = 0; j < tileSize.width; j++) {
        //console.log(i + " " + j + " " + node[i][j][1] + " " + Flag[node[i][j][1]])
        if (node[i][j][1] != 0 && Flag[node[i][j][1]] == 0) {
          console.log("enclosure");
          this.ground.setTileGIDAt(1, i, j);
        }
      }
    }
  },
  //搜索过程
  dfs: function dfs(x, y) {
    //console.log("!!!")
    if (node[x][y][0] == 1) //碰到自己的边
      return;
    if (node[x][y][1] != 0) //不重复搜索
      return;

    if (x == 0 || x == tileSize.width - 1 || y == tileSize.height - 1 || y == 0) {
      Flag[nodeflag_num] = 1; //能到达边界，不是闭合连通片

      return;
    }

    node[x][y][1] = nodeflag_num; //console.log(x + " " + y + " " + nodeflag_num)

    this.dfs(x + 1, y);
    this.dfs(x - 1, y);
    this.dfs(x, y - 1);
    this.dfs(x, y + 1);
    return;
  },
  //加载地图文件时调用
  loadMap: function loadMap() {
    console.log("loadmap"); //初始化地图位置

    this.node.setPosition(cc.visibleRect.bottomLeft); //地图

    this.tiledMap = this.node.getComponent(cc.TiledMap); //player对象层

    var player = this.tiledMap.getObjectGroup('player');
    var birth_point_1 = player.getObject('birth_point1');
    console.log("1"); //像素坐标

    var startPos = cc.v2(birth_point_1.x, birth_point_1.y);
    console.log("startPos" + startPos);
    this.ground = this.tiledMap.getLayer('ground'); //出生Tile

    this.playerTile = this.getTilePos(startPos);
    console.log("start tile" + this.playerTile); //更新player位置

    this.updatePlayerPos();
    tileSize = this.tiledMap.getMapSize();
    ; //地图大小存储到tileSize变量中
  },
  //将像素坐标转化为瓦片坐标
  getTilePos: function getTilePos(posInPixel) {
    var mapSize = this.node.getContentSize();
    var tileSize = this.tiledMap.getTileSize();
    var x = Math.floor(posInPixel.x / tileSize.width);
    var y = Math.floor((mapSize.height - posInPixel.y) / tileSize.height);
    return cc.v2(x, y);
  },
  updatePlayerPos: function updatePlayerPos() {
    //var pos = this.barriers.getPositionAt(this.playerTile);
    var pos = this.ground.getPositionAt(this.playerTile);
    this.ground.setTileGIDAt(1, this.playerTile.x, this.playerTile.y); //填充走过的路径

    this.player_now.setPosition(pos); //console.log(this.player_now.x);
  },
  update: function update(dt) {
    this.timer += dt;

    if (this.timer > 0.25) {
      if (this.Rocker.dir.mag() < 0.5) {} else {
        v_x = this.Rocker.dir.x;
        v_y = this.Rocker.dir.y;
      }

      var newTile = cc.v2(this.playerTile.x, this.playerTile.y);

      if (Math.abs(v_x) > Math.abs(v_y)) {
        if (v_x > 0) newTile.x += 1;else newTile.x -= 1;
      } else {
        if (v_y > 0) newTile.y -= 1;else newTile.y += 1;
      }

      this.tryMoveToNewTile(newTile);
      this.timer = 0;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NpcHRzXFxnYW1lXFxtYXAuanMiXSwibmFtZXMiOlsibm9kZSIsIkFycmF5IiwiRmxhZyIsIm5vZGVmbGFnX251bSIsInRpbGVTaXplIiwidl94Iiwidl95IiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJSb2NrZXIiLCJ0eXBlIiwicmVxdWlyZSIsInNwZWVkIiwic3RhcnQiLCJsb2ciLCJvbkxvYWQiLCJjb25zb2xlIiwicGxheWVyX25vdyIsImdldENoaWxkQnlOYW1lIiwibG9hZE1hcCIsInRpbWVyIiwidHJ5TW92ZVRvTmV3VGlsZSIsIm5ld1RpbGUiLCJtYXBTaXplIiwidGlsZWRNYXAiLCJnZXRNYXBTaXplIiwieCIsIndpZHRoIiwieSIsImhlaWdodCIsImdyb3VuZCIsImdldFRpbGVHSURBdCIsInRyeWVuY2xvc3VyZSIsInBsYXllclRpbGUiLCJ1cGRhdGVQbGF5ZXJQb3MiLCJpIiwiaiIsImsiLCJkZnMiLCJzZXRUaWxlR0lEQXQiLCJzZXRQb3NpdGlvbiIsInZpc2libGVSZWN0IiwiYm90dG9tTGVmdCIsImdldENvbXBvbmVudCIsIlRpbGVkTWFwIiwicGxheWVyIiwiZ2V0T2JqZWN0R3JvdXAiLCJiaXJ0aF9wb2ludF8xIiwiZ2V0T2JqZWN0Iiwic3RhcnRQb3MiLCJ2MiIsImdldExheWVyIiwiZ2V0VGlsZVBvcyIsInBvc0luUGl4ZWwiLCJnZXRDb250ZW50U2l6ZSIsImdldFRpbGVTaXplIiwiTWF0aCIsImZsb29yIiwicG9zIiwiZ2V0UG9zaXRpb25BdCIsInVwZGF0ZSIsImR0IiwiZGlyIiwibWFnIiwiYWJzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUlBLElBQUksR0FBRyxJQUFJQyxLQUFKLEVBQVgsRUFBMEI7O0FBQzFCLElBQUlDLElBQUksR0FBRyxJQUFJRCxLQUFKLENBQVUsR0FBVixDQUFYLEVBQXlCO0FBQ0c7O0FBRTVCLElBQUlFLFlBQUosRUFBNEI7O0FBQzVCLElBQUlDLFFBQUosRUFBNEI7O0FBRTVCLElBQUlDLEdBQUcsR0FBRyxDQUFWO0FBQ0EsSUFBSUMsR0FBRyxHQUFHLENBQVY7QUFFQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFFTEMsRUFBQUEsVUFBVSxFQUFFO0FBRVJDLElBQUFBLE1BQU0sRUFBRTtBQUNKQyxNQUFBQSxJQUFJLEVBQUVDLE9BQU8sQ0FBQyxRQUFELENBRFQ7QUFFSixpQkFBUztBQUZMLEtBRkE7QUFNUkMsSUFBQUEsS0FBSyxFQUFFO0FBTkMsR0FGUDtBQVdMO0FBR0FDLEVBQUFBLEtBQUssRUFBQyxpQkFBVTtBQUNaUixJQUFBQSxFQUFFLENBQUNTLEdBQUgsQ0FBTyxNQUFQLEVBRFksQ0FFWjtBQUNBO0FBQ0gsR0FsQkk7QUFvQkxDLEVBQUFBLE1BQU0sRUFBRSxrQkFBWTtBQUNoQkMsSUFBQUEsT0FBTyxDQUFDRixHQUFSLENBQVksUUFBWjtBQUNBLFNBQUtHLFVBQUwsR0FBa0IsS0FBS25CLElBQUwsQ0FBVW9CLGNBQVYsQ0FBeUIsWUFBekIsQ0FBbEIsQ0FGZ0IsQ0FHZjtBQUNEOztBQUNBLFNBQUtDLE9BQUwsR0FMZ0IsQ0FNaEI7O0FBRUEsU0FBS0MsS0FBTCxHQUFhLENBQWI7QUFDQWpCLElBQUFBLEdBQUcsR0FBRyxDQUFOO0FBQ0FDLElBQUFBLEdBQUcsR0FBRyxDQUFOO0FBQ0gsR0EvQkk7QUFrQ0xpQixFQUFBQSxnQkFBZ0IsRUFBRSwwQkFBVUMsT0FBVixFQUFtQjtBQUNqQyxRQUFJQyxPQUFPLEdBQUcsS0FBS0MsUUFBTCxDQUFjQyxVQUFkLEVBQWQsQ0FEaUMsQ0FHakM7O0FBQ0EsUUFBSUgsT0FBTyxDQUFDSSxDQUFSLEdBQVksQ0FBWixJQUFpQkosT0FBTyxDQUFDSSxDQUFSLElBQWFILE9BQU8sQ0FBQ0ksS0FBMUMsRUFBaUQ7QUFDakQsUUFBSUwsT0FBTyxDQUFDTSxDQUFSLEdBQVksQ0FBWixJQUFpQk4sT0FBTyxDQUFDTSxDQUFSLElBQWFMLE9BQU8sQ0FBQ00sTUFBMUMsRUFBa0QsT0FMakIsQ0FPakM7QUFDRDtBQUNDOztBQUdBLFFBQUksS0FBS0MsTUFBTCxDQUFZQyxZQUFaLENBQXlCVCxPQUF6QixLQUFxQyxDQUF6QyxFQUNHO0FBQ0EsV0FBS1UsWUFBTCxHQWQ4QixDQWNWOztBQUN2QixTQUFLQyxVQUFMLEdBQWtCWCxPQUFsQjtBQUNBLFNBQUtZLGVBQUw7QUFDSCxHQW5ESTtBQXFETEYsRUFBQUEsWUFBWSxFQUFFLHdCQUFZO0FBQ3RCO0FBQ0E7QUFDQS9CLElBQUFBLFlBQVksR0FBRyxDQUFmLENBSHNCLENBR0w7O0FBQ2pCLFNBQUssSUFBSWtDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdqQyxRQUFRLENBQUMyQixNQUE3QixFQUFxQ00sQ0FBQyxFQUF0QyxFQUEwQztBQUN0Q3JDLE1BQUFBLElBQUksQ0FBQ3FDLENBQUQsQ0FBSixHQUFVLElBQUlwQyxLQUFKLEVBQVY7O0FBQ0EsV0FBSyxJQUFJcUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR2xDLFFBQVEsQ0FBQ3lCLEtBQTdCLEVBQW9DUyxDQUFDLEVBQXJDLEVBQXlDO0FBQ3JDdEMsUUFBQUEsSUFBSSxDQUFDcUMsQ0FBRCxDQUFKLENBQVFDLENBQVIsSUFBYSxJQUFJckMsS0FBSixFQUFiOztBQUNBLGFBQUssSUFBSXNDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsQ0FBcEIsRUFBdUJBLENBQUMsRUFBeEI7QUFDSXZDLFVBQUFBLElBQUksQ0FBQ3FDLENBQUQsQ0FBSixDQUFRQyxDQUFSLEVBQVdDLENBQVgsSUFBZ0IsSUFBSXRDLEtBQUosRUFBaEI7QUFESjtBQUVIO0FBQ0osS0FYcUIsQ0FXckI7QUFDRDtBQUNBOzs7QUFFQSxTQUFLLElBQUlvQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHLEdBQXBCLEVBQXlCQSxDQUFDLEVBQTFCO0FBQ0luQyxNQUFBQSxJQUFJLENBQUNtQyxDQUFELENBQUosR0FBVSxDQUFWO0FBREosS0Fmc0IsQ0FpQnRCOzs7QUFDQSxTQUFLLElBQUlBLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdqQyxRQUFRLENBQUMyQixNQUE3QixFQUFxQ00sQ0FBQyxFQUF0QyxFQUEwQztBQUN0QyxXQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdsQyxRQUFRLENBQUN5QixLQUE3QixFQUFvQ1MsQ0FBQyxFQUFyQyxFQUF5QztBQUNyQ3RDLFFBQUFBLElBQUksQ0FBQ3FDLENBQUQsQ0FBSixDQUFRQyxDQUFSLEVBQVcsQ0FBWCxJQUFnQixDQUFoQjtBQUNBdEMsUUFBQUEsSUFBSSxDQUFDcUMsQ0FBRCxDQUFKLENBQVFDLENBQVIsRUFBVyxDQUFYLElBQWdCLENBQWhCO0FBQ0EsWUFBSSxLQUFLTixNQUFMLENBQVlDLFlBQVosQ0FBeUJJLENBQXpCLEVBQTRCQyxDQUE1QixLQUFrQyxDQUF0QyxFQUNJdEMsSUFBSSxDQUFDcUMsQ0FBRCxDQUFKLENBQVFDLENBQVIsRUFBVyxDQUFYLElBQWdCLENBQWhCO0FBQ1A7QUFDSixLQXpCcUIsQ0EyQnZCO0FBQ0M7OztBQUNBLFNBQUssSUFBSUQsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR2pDLFFBQVEsQ0FBQzJCLE1BQTdCLEVBQXFDTSxDQUFDLEVBQXRDLEVBQTBDO0FBQ3RDLFdBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR2xDLFFBQVEsQ0FBQ3lCLEtBQTdCLEVBQW9DUyxDQUFDLEVBQXJDLEVBQXlDO0FBQ3JDO0FBQ0EsWUFBSXRDLElBQUksQ0FBQ3FDLENBQUQsQ0FBSixDQUFRQyxDQUFSLEVBQVcsQ0FBWCxLQUFpQixDQUFqQixJQUFzQnRDLElBQUksQ0FBQ3FDLENBQUQsQ0FBSixDQUFRQyxDQUFSLEVBQVcsQ0FBWCxLQUFpQixDQUEzQyxFQUE4QztBQUMxQztBQUNBO0FBQ0EsZUFBS0UsR0FBTCxDQUFTSCxDQUFULEVBQVlDLENBQVo7QUFDQW5DLFVBQUFBLFlBQVksR0FBQ0EsWUFBWSxHQUFDLENBQTFCO0FBQ0g7QUFDSjtBQUNKLEtBdkNxQixDQXdDdEI7QUFDQTs7O0FBQ0EsU0FBSyxJQUFJa0MsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR2pDLFFBQVEsQ0FBQzJCLE1BQTdCLEVBQXFDTSxDQUFDLEVBQXRDLEVBQTBDO0FBQ3RDLFdBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR2xDLFFBQVEsQ0FBQ3lCLEtBQTdCLEVBQW9DUyxDQUFDLEVBQXJDLEVBQXlDO0FBQ3JDO0FBQ0EsWUFBSXRDLElBQUksQ0FBQ3FDLENBQUQsQ0FBSixDQUFRQyxDQUFSLEVBQVcsQ0FBWCxLQUFpQixDQUFqQixJQUFzQnBDLElBQUksQ0FBQ0YsSUFBSSxDQUFDcUMsQ0FBRCxDQUFKLENBQVFDLENBQVIsRUFBVyxDQUFYLENBQUQsQ0FBSixJQUF1QixDQUFqRCxFQUFvRDtBQUNoRHBCLFVBQUFBLE9BQU8sQ0FBQ0YsR0FBUixDQUFZLFdBQVo7QUFDQSxlQUFLZ0IsTUFBTCxDQUFZUyxZQUFaLENBQXlCLENBQXpCLEVBQTRCSixDQUE1QixFQUErQkMsQ0FBL0I7QUFDSDtBQUNKO0FBQ0o7QUFDSixHQXhHSTtBQTBHTDtBQUNBRSxFQUFBQSxHQUFHLEVBQUMsYUFBU1osQ0FBVCxFQUFZRSxDQUFaLEVBQWU7QUFDZjtBQUNBLFFBQUk5QixJQUFJLENBQUM0QixDQUFELENBQUosQ0FBUUUsQ0FBUixFQUFXLENBQVgsS0FBaUIsQ0FBckIsRUFBdUI7QUFDbkI7QUFDSixRQUFJOUIsSUFBSSxDQUFDNEIsQ0FBRCxDQUFKLENBQVFFLENBQVIsRUFBVyxDQUFYLEtBQWlCLENBQXJCLEVBQXVCO0FBQ25COztBQUNKLFFBQUlGLENBQUMsSUFBSSxDQUFMLElBQVVBLENBQUMsSUFBSXhCLFFBQVEsQ0FBQ3lCLEtBQVQsR0FBZSxDQUE5QixJQUFtQ0MsQ0FBQyxJQUFJMUIsUUFBUSxDQUFDMkIsTUFBVCxHQUFnQixDQUF4RCxJQUE2REQsQ0FBQyxJQUFJLENBQXRFLEVBQXlFO0FBQ3JFNUIsTUFBQUEsSUFBSSxDQUFDQyxZQUFELENBQUosR0FBcUIsQ0FBckIsQ0FEcUUsQ0FDOUM7O0FBQ3ZCO0FBQ0g7O0FBQ0RILElBQUFBLElBQUksQ0FBQzRCLENBQUQsQ0FBSixDQUFRRSxDQUFSLEVBQVcsQ0FBWCxJQUFnQjNCLFlBQWhCLENBVmUsQ0FXZjs7QUFDQSxTQUFLcUMsR0FBTCxDQUFTWixDQUFDLEdBQUcsQ0FBYixFQUFnQkUsQ0FBaEI7QUFDQSxTQUFLVSxHQUFMLENBQVNaLENBQUMsR0FBRyxDQUFiLEVBQWVFLENBQWY7QUFDQSxTQUFLVSxHQUFMLENBQVNaLENBQVQsRUFBWUUsQ0FBQyxHQUFHLENBQWhCO0FBQ0EsU0FBS1UsR0FBTCxDQUFTWixDQUFULEVBQVlFLENBQUMsR0FBRyxDQUFoQjtBQUNBO0FBQ0gsR0E1SEk7QUErSEw7QUFDQVQsRUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCSCxJQUFBQSxPQUFPLENBQUNGLEdBQVIsQ0FBWSxTQUFaLEVBRGlCLENBRWpCOztBQUNBLFNBQUtoQixJQUFMLENBQVUwQyxXQUFWLENBQXNCbkMsRUFBRSxDQUFDb0MsV0FBSCxDQUFlQyxVQUFyQyxFQUhpQixDQUtqQjs7QUFDQSxTQUFLbEIsUUFBTCxHQUFnQixLQUFLMUIsSUFBTCxDQUFVNkMsWUFBVixDQUF1QnRDLEVBQUUsQ0FBQ3VDLFFBQTFCLENBQWhCLENBTmlCLENBUWpCOztBQUNBLFFBQUlDLE1BQU0sR0FBRyxLQUFLckIsUUFBTCxDQUFjc0IsY0FBZCxDQUE2QixRQUE3QixDQUFiO0FBRUEsUUFBSUMsYUFBYSxHQUFHRixNQUFNLENBQUNHLFNBQVAsQ0FBaUIsY0FBakIsQ0FBcEI7QUFFQWhDLElBQUFBLE9BQU8sQ0FBQ0YsR0FBUixDQUFZLEdBQVosRUFiaUIsQ0FjakI7O0FBRUEsUUFBSW1DLFFBQVEsR0FBRzVDLEVBQUUsQ0FBQzZDLEVBQUgsQ0FBTUgsYUFBYSxDQUFDckIsQ0FBcEIsRUFBdUJxQixhQUFhLENBQUNuQixDQUFyQyxDQUFmO0FBQ0FaLElBQUFBLE9BQU8sQ0FBQ0YsR0FBUixDQUFZLGFBQVdtQyxRQUF2QjtBQUVBLFNBQUtuQixNQUFMLEdBQWMsS0FBS04sUUFBTCxDQUFjMkIsUUFBZCxDQUF1QixRQUF2QixDQUFkLENBbkJpQixDQXFCakI7O0FBQ0EsU0FBS2xCLFVBQUwsR0FBa0IsS0FBS21CLFVBQUwsQ0FBZ0JILFFBQWhCLENBQWxCO0FBQ0FqQyxJQUFBQSxPQUFPLENBQUNGLEdBQVIsQ0FBWSxlQUFhLEtBQUttQixVQUE5QixFQXZCaUIsQ0F3QmpCOztBQUNBLFNBQUtDLGVBQUw7QUFFQWhDLElBQUFBLFFBQVEsR0FBRyxLQUFLc0IsUUFBTCxDQUFjQyxVQUFkLEVBQVg7QUFBc0MsS0EzQnJCLENBMkJzQjtBQUMxQyxHQTVKSTtBQStKSjtBQUNEMkIsRUFBQUEsVUFBVSxFQUFFLG9CQUFVQyxVQUFWLEVBQXNCO0FBQzlCLFFBQUk5QixPQUFPLEdBQUcsS0FBS3pCLElBQUwsQ0FBVXdELGNBQVYsRUFBZDtBQUNBLFFBQUlwRCxRQUFRLEdBQUcsS0FBS3NCLFFBQUwsQ0FBYytCLFdBQWQsRUFBZjtBQUNBLFFBQUk3QixDQUFDLEdBQUc4QixJQUFJLENBQUNDLEtBQUwsQ0FBV0osVUFBVSxDQUFDM0IsQ0FBWCxHQUFleEIsUUFBUSxDQUFDeUIsS0FBbkMsQ0FBUjtBQUNBLFFBQUlDLENBQUMsR0FBRzRCLElBQUksQ0FBQ0MsS0FBTCxDQUFXLENBQUNsQyxPQUFPLENBQUNNLE1BQVIsR0FBaUJ3QixVQUFVLENBQUN6QixDQUE3QixJQUFrQzFCLFFBQVEsQ0FBQzJCLE1BQXRELENBQVI7QUFDQSxXQUFPeEIsRUFBRSxDQUFDNkMsRUFBSCxDQUFNeEIsQ0FBTixFQUFTRSxDQUFULENBQVA7QUFDSCxHQXRLSTtBQXdLTE0sRUFBQUEsZUFBZSxFQUFFLDJCQUFZO0FBQ3pCO0FBQ0EsUUFBSXdCLEdBQUcsR0FBRyxLQUFLNUIsTUFBTCxDQUFZNkIsYUFBWixDQUEwQixLQUFLMUIsVUFBL0IsQ0FBVjtBQUNBLFNBQUtILE1BQUwsQ0FBWVMsWUFBWixDQUF5QixDQUF6QixFQUE0QixLQUFLTixVQUFMLENBQWdCUCxDQUE1QyxFQUErQyxLQUFLTyxVQUFMLENBQWdCTCxDQUEvRCxFQUh5QixDQUkxQjs7QUFDQyxTQUFLWCxVQUFMLENBQWdCdUIsV0FBaEIsQ0FBNEJrQixHQUE1QixFQUx5QixDQU16QjtBQUNILEdBL0tJO0FBaUxMRSxFQUFBQSxNQWpMSyxrQkFpTEVDLEVBakxGLEVBaUxNO0FBQ1AsU0FBS3pDLEtBQUwsSUFBY3lDLEVBQWQ7O0FBQ0EsUUFBSSxLQUFLekMsS0FBTCxHQUFhLElBQWpCLEVBQXVCO0FBQ25CLFVBQUksS0FBS1gsTUFBTCxDQUFZcUQsR0FBWixDQUFnQkMsR0FBaEIsS0FBd0IsR0FBNUIsRUFBaUMsQ0FDaEMsQ0FERCxNQUVLO0FBQ0Q1RCxRQUFBQSxHQUFHLEdBQUcsS0FBS00sTUFBTCxDQUFZcUQsR0FBWixDQUFnQnBDLENBQXRCO0FBQ0F0QixRQUFBQSxHQUFHLEdBQUcsS0FBS0ssTUFBTCxDQUFZcUQsR0FBWixDQUFnQmxDLENBQXRCO0FBQ0g7O0FBQ0QsVUFBSU4sT0FBTyxHQUFHakIsRUFBRSxDQUFDNkMsRUFBSCxDQUFNLEtBQUtqQixVQUFMLENBQWdCUCxDQUF0QixFQUF5QixLQUFLTyxVQUFMLENBQWdCTCxDQUF6QyxDQUFkOztBQUNBLFVBQUk0QixJQUFJLENBQUNRLEdBQUwsQ0FBUzdELEdBQVQsSUFBZ0JxRCxJQUFJLENBQUNRLEdBQUwsQ0FBUzVELEdBQVQsQ0FBcEIsRUFBbUM7QUFDL0IsWUFBSUQsR0FBRyxHQUFHLENBQVYsRUFDSW1CLE9BQU8sQ0FBQ0ksQ0FBUixJQUFhLENBQWIsQ0FESixLQUdJSixPQUFPLENBQUNJLENBQVIsSUFBYSxDQUFiO0FBQ1AsT0FMRCxNQU1LO0FBQ0QsWUFBSXRCLEdBQUcsR0FBRyxDQUFWLEVBQ0lrQixPQUFPLENBQUNNLENBQVIsSUFBYSxDQUFiLENBREosS0FHSU4sT0FBTyxDQUFDTSxDQUFSLElBQWEsQ0FBYjtBQUNQOztBQUNELFdBQUtQLGdCQUFMLENBQXNCQyxPQUF0QjtBQUNBLFdBQUtGLEtBQUwsR0FBYSxDQUFiO0FBQ0g7QUFDSjtBQTFNSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgbm9kZSA9IG5ldyBBcnJheSgpICAgIC8v5aGr6Imy5pWw57uEXHJcbnZhciBGbGFnID0gbmV3IEFycmF5KDEwMCkvL+i/numAmueJh+aVsOebruacgOWkmuS4ujMw77yM5ZCm5YiZ5q2k5aSE6ZyA57un57ut5aKe5Yqg5YC8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL+esrGnkuKrogZTpgJrniYfmmK/lkKbmmK/pooblnLDlhoXnmoTmoIforrDvvIzkuLow5YiZ5pivXHJcblxyXG52YXIgbm9kZWZsYWdfbnVtICAgICAgICAgICAgLy/ogZTpgJrniYfmlbDph4/nmoTorqHmlbBcclxudmFyIHRpbGVTaXplICAgICAgICAgICAgICAgIC8v5Zyw5Zu+5aSn5bCPXHJcblxyXG52YXIgdl94ID0gMDtcclxudmFyIHZfeSA9IDA7XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgICAgIFJvY2tlcjoge1xyXG4gICAgICAgICAgICB0eXBlOiByZXF1aXJlKFwiUm9ja2VyXCIpLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc3BlZWQ6IDEwMCxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG5cclxuICAgIHN0YXJ0OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MubG9nKFwiISEhIVwiKTtcclxuICAgICAgICAvL2NjLmxvZyh1c2VyX25hbWUudG9TdHJpbmcoKSk7XHJcbiAgICAgICAgLy9jYy5sb2codXNlcl9jb2RlLnRvU3RyaW5nKCkpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIm9uTG9hZFwiKTtcclxuICAgICAgICB0aGlzLnBsYXllcl9ub3cgPSB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ3BsYXllcl9ub3cnKTtcclxuICAgICAgICAgLy/ojrflj5ZwbGF5ZXJfbm936IqC54K5XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZyh0aGlzLnBsYXllcl9ub3cpXHJcbiAgICAgICAgdGhpcy5sb2FkTWFwKCk7XHJcbiAgICAgICAgLy/liqDovb3lnLDlm75cclxuICAgICAgICBcclxuICAgICAgICB0aGlzLnRpbWVyID0gMDtcclxuICAgICAgICB2X3ggPSAxO1xyXG4gICAgICAgIHZfeSA9IDA7XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICB0cnlNb3ZlVG9OZXdUaWxlOiBmdW5jdGlvbiAobmV3VGlsZSkge1xyXG4gICAgICAgIHZhciBtYXBTaXplID0gdGhpcy50aWxlZE1hcC5nZXRNYXBTaXplKCk7XHJcblxyXG4gICAgICAgIC8v6LaF5Ye66L6555WM77yM55u05o6l6L+U5ZueXHJcbiAgICAgICAgaWYgKG5ld1RpbGUueCA8IDAgfHwgbmV3VGlsZS54ID49IG1hcFNpemUud2lkdGgpIHJldHVybjtcclxuICAgICAgICBpZiAobmV3VGlsZS55IDwgMCB8fCBuZXdUaWxlLnkgPj0gbWFwU2l6ZS5oZWlnaHQpIHJldHVybjtcclxuXHJcbiAgICAgICAgLy9jb25zb2xlLmxvZyh0aGlzLmdyb3VuZC5nZXRUaWxlR0lEQXQobmV3VGlsZSkpXHJcbiAgICAgICAvLzHmmK/loavlhYXlnZcsMuaYr+mdnuWhq+WFheWdl1xyXG4gICAgICAgIC8vdGhpcy5ncm91bmQuc2V0VGlsZUdJREF0KDEsbmV3VGlsZS54LG5ld1RpbGUueSlcclxuXHJcblxyXG4gICAgICAgIGlmICh0aGlzLmdyb3VuZC5nZXRUaWxlR0lEQXQobmV3VGlsZSkgPT0gMSlcclxuICAgICAgICAgICAvL+WmguaenOW9k+WJjeS9jee9ruS4juW3suWhq+WFheWdl+mHjeWPoO+8jOWwneivleWciOWcsFxyXG4gICAgICAgICAgIHRoaXMudHJ5ZW5jbG9zdXJlKCk7Ly/lsJ3or5XlnIjlnLBcclxuICAgICAgICB0aGlzLnBsYXllclRpbGUgPSBuZXdUaWxlO1xyXG4gICAgICAgIHRoaXMudXBkYXRlUGxheWVyUG9zKCk7XHJcbiAgICB9LFxyXG5cclxuICAgIHRyeWVuY2xvc3VyZTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIC8vY29uc29sZS5sb2coXCJ0cnkgdG8gZW5jbG9zdXJlXCIpXHJcbiAgICAgICAgLy92YXIgTm9kZV9BID0gbmV3IEFycmF5KCk7XHJcbiAgICAgICAgbm9kZWZsYWdfbnVtID0gMTsvL+iBlOmAmueJh+aVsOmHj+eahOiuoeaVsFxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGlsZVNpemUuaGVpZ2h0OyBpKyspIHtcclxuICAgICAgICAgICAgbm9kZVtpXSA9IG5ldyBBcnJheSgpO1xyXG4gICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHRpbGVTaXplLndpZHRoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIG5vZGVbaV1bal0gPSBuZXcgQXJyYXkoKTtcclxuICAgICAgICAgICAgICAgIGZvciAodmFyIGsgPSAwOyBrIDwgMzsgaysrKVxyXG4gICAgICAgICAgICAgICAgICAgIG5vZGVbaV1bal1ba10gPSBuZXcgQXJyYXkoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0vL+ebuOW9k+S6juaYr05vZGVfQVtoZWlnaHRdW3dpZHRoXVszXVxyXG4gICAgICAgIC8vTm9kZV9BW2hlaWdodF1bd2lkdGhdWzBd5qCH6K+G6K+l54K55piv5aGr5YWF5Z2X6L+Y5piv6Z2e5aGr5YWF5Z2XXHJcbiAgICAgICAgLy9bMV3moIfor4bor6XngrnmmK/lk6rkuIDkuKrogZTpgJrniYdcclxuXHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCAxMDA7IGkrKylcclxuICAgICAgICAgICAgRmxhZ1tpXSA9IDA7XHJcbiAgICAgICAgLy/ojrflj5bmlbTkuKrlnLDlm77nmoTloavoibLkv6Hmga9cclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRpbGVTaXplLmhlaWdodDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgdGlsZVNpemUud2lkdGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgbm9kZVtpXVtqXVswXSA9IDA7XHJcbiAgICAgICAgICAgICAgICBub2RlW2ldW2pdWzFdID0gMDtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmdyb3VuZC5nZXRUaWxlR0lEQXQoaSwgaikgPT0gMSlcclxuICAgICAgICAgICAgICAgICAgICBub2RlW2ldW2pdWzBdID0gMTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAvL+a3seW6puS8mOWFiOaQnOe0ouWwneivleWhq+WFhVxyXG4gICAgICAgIC8v5YiG5Yir5LuO5LiK5LiL5bem5Y+z5pCc5a+777yM6L+b6KGM5rex5bqm5LyY5YWI5pCc57SiXHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aWxlU2l6ZS5oZWlnaHQ7IGkrKykge1xyXG4gICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHRpbGVTaXplLndpZHRoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coaStcIiBcIitqK1wibm9kZVwiK25vZGVbaV1bal1bMF0pXHJcbiAgICAgICAgICAgICAgICBpZiAobm9kZVtpXVtqXVswXSA9PSAwICYmIG5vZGVbaV1bal1bMV0gPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coaStcIkBAQFwiKVxyXG4gICAgICAgICAgICAgICAgICAgIC8v6Iul5pyq5raC5a6e6Imy5LiU5LiN5bGe5LqO5LmL5YmN5Lu75L2V6IGU6YCa54mH77yM5LuO5q2k54K55pCc57Si5paw6IGU6YCa54mHXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kZnMoaSwgaik7XHJcbiAgICAgICAgICAgICAgICAgICAgbm9kZWZsYWdfbnVtPW5vZGVmbGFnX251bSsxO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vY29uc29sZS5sb2coXCIhXCIpXHJcbiAgICAgICAgLy/lsIbmiYDmnInpl63ogZTpgJrniYfmtoLlrp5cclxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRpbGVTaXplLmhlaWdodDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgdGlsZVNpemUud2lkdGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhpICsgXCIgXCIgKyBqICsgXCIgXCIgKyBub2RlW2ldW2pdWzFdICsgXCIgXCIgKyBGbGFnW25vZGVbaV1bal1bMV1dKVxyXG4gICAgICAgICAgICAgICAgaWYgKG5vZGVbaV1bal1bMV0gIT0gMCAmJiBGbGFnW25vZGVbaV1bal1bMV1dID09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImVuY2xvc3VyZVwiKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ3JvdW5kLnNldFRpbGVHSURBdCgxLCBpLCBqKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvL+aQnOe0oui/h+eoi1xyXG4gICAgZGZzOmZ1bmN0aW9uKHgsIHkpIHtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKFwiISEhXCIpXHJcbiAgICAgICAgaWYgKG5vZGVbeF1beV1bMF0gPT0gMSkvL+eisOWIsOiHquW3seeahOi+uVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgaWYgKG5vZGVbeF1beV1bMV0gIT0gMCkvL+S4jemHjeWkjeaQnOe0olxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgaWYgKHggPT0gMCB8fCB4ID09IHRpbGVTaXplLndpZHRoLTEgfHwgeSA9PSB0aWxlU2l6ZS5oZWlnaHQtMSB8fCB5ID09IDApIHtcclxuICAgICAgICAgICAgRmxhZ1tub2RlZmxhZ19udW1dID0gMTsvL+iDveWIsOi+vui+ueeVjO+8jOS4jeaYr+mXreWQiOi/numAmueJh1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG5vZGVbeF1beV1bMV0gPSBub2RlZmxhZ19udW07XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZyh4ICsgXCIgXCIgKyB5ICsgXCIgXCIgKyBub2RlZmxhZ19udW0pXHJcbiAgICAgICAgdGhpcy5kZnMoeCArIDEsIHkpXHJcbiAgICAgICAgdGhpcy5kZnMoeCAtIDEseSlcclxuICAgICAgICB0aGlzLmRmcyh4LCB5IC0gMSlcclxuICAgICAgICB0aGlzLmRmcyh4LCB5ICsgMSlcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICAvL+WKoOi9veWcsOWbvuaWh+S7tuaXtuiwg+eUqFxyXG4gICAgbG9hZE1hcDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwibG9hZG1hcFwiKTtcclxuICAgICAgICAvL+WIneWni+WMluWcsOWbvuS9jee9rlxyXG4gICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbihjYy52aXNpYmxlUmVjdC5ib3R0b21MZWZ0KTtcclxuXHJcbiAgICAgICAgLy/lnLDlm75cclxuICAgICAgICB0aGlzLnRpbGVkTWFwID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5UaWxlZE1hcCk7XHJcblxyXG4gICAgICAgIC8vcGxheWVy5a+56LGh5bGCXHJcbiAgICAgICAgdmFyIHBsYXllciA9IHRoaXMudGlsZWRNYXAuZ2V0T2JqZWN0R3JvdXAoJ3BsYXllcicpO1xyXG5cclxuICAgICAgICB2YXIgYmlydGhfcG9pbnRfMSA9IHBsYXllci5nZXRPYmplY3QoJ2JpcnRoX3BvaW50MScpO1xyXG5cclxuICAgICAgICBjb25zb2xlLmxvZyhcIjFcIik7XHJcbiAgICAgICAgLy/lg4/ntKDlnZDmoIdcclxuXHJcbiAgICAgICAgdmFyIHN0YXJ0UG9zID0gY2MudjIoYmlydGhfcG9pbnRfMS54LCBiaXJ0aF9wb2ludF8xLnkpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwic3RhcnRQb3NcIitzdGFydFBvcyk7XHJcblxyXG4gICAgICAgIHRoaXMuZ3JvdW5kID0gdGhpcy50aWxlZE1hcC5nZXRMYXllcignZ3JvdW5kJyk7XHJcblxyXG4gICAgICAgIC8v5Ye655SfVGlsZVxyXG4gICAgICAgIHRoaXMucGxheWVyVGlsZSA9IHRoaXMuZ2V0VGlsZVBvcyhzdGFydFBvcyk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJzdGFydCB0aWxlXCIrdGhpcy5wbGF5ZXJUaWxlKVxyXG4gICAgICAgIC8v5pu05pawcGxheWVy5L2N572uXHJcbiAgICAgICAgdGhpcy51cGRhdGVQbGF5ZXJQb3MoKTtcclxuXHJcbiAgICAgICAgdGlsZVNpemUgPSB0aGlzLnRpbGVkTWFwLmdldE1hcFNpemUoKTs7Ly/lnLDlm77lpKflsI/lrZjlgqjliLB0aWxlU2l6ZeWPmOmHj+S4rVxyXG4gICAgfSxcclxuXHJcblxyXG4gICAgIC8v5bCG5YOP57Sg5Z2Q5qCH6L2s5YyW5Li655Om54mH5Z2Q5qCHXHJcbiAgICBnZXRUaWxlUG9zOiBmdW5jdGlvbiAocG9zSW5QaXhlbCkge1xyXG4gICAgICAgIHZhciBtYXBTaXplID0gdGhpcy5ub2RlLmdldENvbnRlbnRTaXplKCk7XHJcbiAgICAgICAgdmFyIHRpbGVTaXplID0gdGhpcy50aWxlZE1hcC5nZXRUaWxlU2l6ZSgpO1xyXG4gICAgICAgIHZhciB4ID0gTWF0aC5mbG9vcihwb3NJblBpeGVsLnggLyB0aWxlU2l6ZS53aWR0aCk7XHJcbiAgICAgICAgdmFyIHkgPSBNYXRoLmZsb29yKChtYXBTaXplLmhlaWdodCAtIHBvc0luUGl4ZWwueSkgLyB0aWxlU2l6ZS5oZWlnaHQpO1xyXG4gICAgICAgIHJldHVybiBjYy52Mih4LCB5KTtcclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlUGxheWVyUG9zOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgLy92YXIgcG9zID0gdGhpcy5iYXJyaWVycy5nZXRQb3NpdGlvbkF0KHRoaXMucGxheWVyVGlsZSk7XHJcbiAgICAgICAgdmFyIHBvcyA9IHRoaXMuZ3JvdW5kLmdldFBvc2l0aW9uQXQodGhpcy5wbGF5ZXJUaWxlKTtcclxuICAgICAgICB0aGlzLmdyb3VuZC5zZXRUaWxlR0lEQXQoMSwgdGhpcy5wbGF5ZXJUaWxlLngsIHRoaXMucGxheWVyVGlsZS55KVxyXG4gICAgICAgLy/loavlhYXotbDov4fnmoTot6/lvoRcclxuICAgICAgICB0aGlzLnBsYXllcl9ub3cuc2V0UG9zaXRpb24ocG9zKTtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKHRoaXMucGxheWVyX25vdy54KTtcclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlKGR0KSB7XHJcbiAgICAgICAgdGhpcy50aW1lciArPSBkdDtcclxuICAgICAgICBpZiAodGhpcy50aW1lciA+IDAuMjUpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuUm9ja2VyLmRpci5tYWcoKSA8IDAuNSkge1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdl94ID0gdGhpcy5Sb2NrZXIuZGlyLng7XHJcbiAgICAgICAgICAgICAgICB2X3kgPSB0aGlzLlJvY2tlci5kaXIueTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB2YXIgbmV3VGlsZSA9IGNjLnYyKHRoaXMucGxheWVyVGlsZS54LCB0aGlzLnBsYXllclRpbGUueSk7XHJcbiAgICAgICAgICAgIGlmIChNYXRoLmFicyh2X3gpID4gTWF0aC5hYnModl95KSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHZfeCA+IDApXHJcbiAgICAgICAgICAgICAgICAgICAgbmV3VGlsZS54ICs9IDE7XHJcbiAgICAgICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICAgICAgbmV3VGlsZS54IC09IDE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodl95ID4gMClcclxuICAgICAgICAgICAgICAgICAgICBuZXdUaWxlLnkgLT0gMTtcclxuICAgICAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgICAgICBuZXdUaWxlLnkgKz0gMTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLnRyeU1vdmVUb05ld1RpbGUobmV3VGlsZSk7XHJcbiAgICAgICAgICAgIHRoaXMudGltZXIgPSAwO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scipts/game/Rocker.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '28d7ef5RfFC7pvGiaBD0KJG', 'Rocker');
// scipts/game/Rocker.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    Rocker: {
      type: cc.Node,
      "default": null
    },
    Max_r: 100
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.Rocker.x = 0;
    this.Rocker.y = 0;
    this.dir = cc.v2(0, 0);
    this.Rocker.on(cc.Node.EventType.TOUCH_START, function (e) {
      var w_pos = e.getLocation();
      var pos = this.node.convertToNodeSpaceAR(w_pos); //将世界坐标转化为父节点的相对坐标

      var len = pos.mag();
      this.dir.x = pos.x / len;
      this.dir.y = pos.y / len;

      if (len > this.Max_r) {
        pos.x = this.Max_r * pos.x / len;
        pos.y = this.Max_r * pos.y / len;
      }

      this.Rocker.setPosition(pos);
    }, this);
    this.Rocker.on(cc.Node.EventType.TOUCH_MOVE, function (e) {
      var w_pos = e.getLocation();
      var pos = this.node.convertToNodeSpaceAR(w_pos); //将世界坐标转化为父节点的相对坐标

      var len = pos.mag();
      this.dir.x = pos.x / len;
      this.dir.y = pos.y / len;

      if (len > this.Max_r) {
        pos.x = this.Max_r * pos.x / len;
        pos.y = this.Max_r * pos.y / len;
      }

      this.Rocker.setPosition(pos);
    }, this);
    this.Rocker.on(cc.Node.EventType.TOUCH_END, function (e) {
      this.Rocker.setPosition(cc.v2(0, 0));
      this.dir = cc.v2(0, 0);
    }, this);
    this.Rocker.on(cc.Node.EventType.TOUCH_CANCEL, function (e) {
      this.Rocker.setPosition(cc.v2(0, 0));
      this.dir = cc.v2(0, 0);
    }, this);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NpcHRzXFxnYW1lXFxSb2NrZXIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJSb2NrZXIiLCJ0eXBlIiwiTm9kZSIsIk1heF9yIiwic3RhcnQiLCJ4IiwieSIsImRpciIsInYyIiwib24iLCJFdmVudFR5cGUiLCJUT1VDSF9TVEFSVCIsImUiLCJ3X3BvcyIsImdldExvY2F0aW9uIiwicG9zIiwibm9kZSIsImNvbnZlcnRUb05vZGVTcGFjZUFSIiwibGVuIiwibWFnIiwic2V0UG9zaXRpb24iLCJUT1VDSF9NT1ZFIiwiVE9VQ0hfRU5EIiwiVE9VQ0hfQ0FOQ0VMIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFHUkMsSUFBQUEsTUFBTSxFQUFDO0FBQ0hDLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDTSxJQURMO0FBRUgsaUJBQVE7QUFGTCxLQUhDO0FBUVJDLElBQUFBLEtBQUssRUFBQztBQVJFLEdBSFA7QUFjTDtBQUVBO0FBRUFDLEVBQUFBLEtBbEJLLG1CQWtCSTtBQUNMLFNBQUtKLE1BQUwsQ0FBWUssQ0FBWixHQUFnQixDQUFoQjtBQUNBLFNBQUtMLE1BQUwsQ0FBWU0sQ0FBWixHQUFnQixDQUFoQjtBQUNBLFNBQUtDLEdBQUwsR0FBV1gsRUFBRSxDQUFDWSxFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBWDtBQUVBLFNBQUtSLE1BQUwsQ0FBWVMsRUFBWixDQUFlYixFQUFFLENBQUNNLElBQUgsQ0FBUVEsU0FBUixDQUFrQkMsV0FBakMsRUFBNkMsVUFBU0MsQ0FBVCxFQUFXO0FBQ3BELFVBQUlDLEtBQUssR0FBR0QsQ0FBQyxDQUFDRSxXQUFGLEVBQVo7QUFDRCxVQUFJQyxHQUFHLEdBQUcsS0FBS0MsSUFBTCxDQUFVQyxvQkFBVixDQUErQkosS0FBL0IsQ0FBVixDQUZxRCxDQUVMOztBQUUvQyxVQUFJSyxHQUFHLEdBQUdILEdBQUcsQ0FBQ0ksR0FBSixFQUFWO0FBQ0EsV0FBS1osR0FBTCxDQUFTRixDQUFULEdBQWFVLEdBQUcsQ0FBQ1YsQ0FBSixHQUFRYSxHQUFyQjtBQUNBLFdBQUtYLEdBQUwsQ0FBU0QsQ0FBVCxHQUFhUyxHQUFHLENBQUNULENBQUosR0FBUVksR0FBckI7O0FBQ0EsVUFBR0EsR0FBRyxHQUFHLEtBQUtmLEtBQWQsRUFBb0I7QUFDaEJZLFFBQUFBLEdBQUcsQ0FBQ1YsQ0FBSixHQUFRLEtBQUtGLEtBQUwsR0FBYVksR0FBRyxDQUFDVixDQUFqQixHQUFxQmEsR0FBN0I7QUFDQUgsUUFBQUEsR0FBRyxDQUFDVCxDQUFKLEdBQVEsS0FBS0gsS0FBTCxHQUFhWSxHQUFHLENBQUNULENBQWpCLEdBQXFCWSxHQUE3QjtBQUNIOztBQUNELFdBQUtsQixNQUFMLENBQVlvQixXQUFaLENBQXdCTCxHQUF4QjtBQUNILEtBWkQsRUFZRSxJQVpGO0FBY0EsU0FBS2YsTUFBTCxDQUFZUyxFQUFaLENBQWViLEVBQUUsQ0FBQ00sSUFBSCxDQUFRUSxTQUFSLENBQWtCVyxVQUFqQyxFQUE0QyxVQUFTVCxDQUFULEVBQVc7QUFDcEQsVUFBSUMsS0FBSyxHQUFHRCxDQUFDLENBQUNFLFdBQUYsRUFBWjtBQUNBLFVBQUlDLEdBQUcsR0FBRyxLQUFLQyxJQUFMLENBQVVDLG9CQUFWLENBQStCSixLQUEvQixDQUFWLENBRm9ELENBRUo7O0FBRy9DLFVBQUlLLEdBQUcsR0FBR0gsR0FBRyxDQUFDSSxHQUFKLEVBQVY7QUFDQSxXQUFLWixHQUFMLENBQVNGLENBQVQsR0FBYVUsR0FBRyxDQUFDVixDQUFKLEdBQVFhLEdBQXJCO0FBQ0EsV0FBS1gsR0FBTCxDQUFTRCxDQUFULEdBQWFTLEdBQUcsQ0FBQ1QsQ0FBSixHQUFRWSxHQUFyQjs7QUFDQSxVQUFHQSxHQUFHLEdBQUcsS0FBS2YsS0FBZCxFQUFvQjtBQUNoQlksUUFBQUEsR0FBRyxDQUFDVixDQUFKLEdBQVEsS0FBS0YsS0FBTCxHQUFhWSxHQUFHLENBQUNWLENBQWpCLEdBQXFCYSxHQUE3QjtBQUNBSCxRQUFBQSxHQUFHLENBQUNULENBQUosR0FBUSxLQUFLSCxLQUFMLEdBQWFZLEdBQUcsQ0FBQ1QsQ0FBakIsR0FBcUJZLEdBQTdCO0FBQ0g7O0FBQ0QsV0FBS2xCLE1BQUwsQ0FBWW9CLFdBQVosQ0FBd0JMLEdBQXhCO0FBQ0gsS0FiRCxFQWFFLElBYkY7QUFlQSxTQUFLZixNQUFMLENBQVlTLEVBQVosQ0FBZWIsRUFBRSxDQUFDTSxJQUFILENBQVFRLFNBQVIsQ0FBa0JZLFNBQWpDLEVBQTJDLFVBQVNWLENBQVQsRUFBVztBQUNuRCxXQUFLWixNQUFMLENBQVlvQixXQUFaLENBQXdCeEIsRUFBRSxDQUFDWSxFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBeEI7QUFDTCxXQUFLRCxHQUFMLEdBQVdYLEVBQUUsQ0FBQ1ksRUFBSCxDQUFNLENBQU4sRUFBUyxDQUFULENBQVg7QUFDRyxLQUhELEVBR0UsSUFIRjtBQUtBLFNBQUtSLE1BQUwsQ0FBWVMsRUFBWixDQUFlYixFQUFFLENBQUNNLElBQUgsQ0FBUVEsU0FBUixDQUFrQmEsWUFBakMsRUFBOEMsVUFBU1gsQ0FBVCxFQUFXO0FBQ3JELFdBQUtaLE1BQUwsQ0FBWW9CLFdBQVosQ0FBd0J4QixFQUFFLENBQUNZLEVBQUgsQ0FBTSxDQUFOLEVBQVEsQ0FBUixDQUF4QjtBQUNSLFdBQUtELEdBQUwsR0FBV1gsRUFBRSxDQUFDWSxFQUFILENBQU0sQ0FBTixFQUFTLENBQVQsQ0FBWDtBQUNLLEtBSEQsRUFHRSxJQUhGO0FBSUgsR0E3REksQ0E4REw7O0FBOURLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHJcblxyXG4gICAgICAgIFJvY2tlcjp7XHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIE1heF9yOjEwMCxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICB0aGlzLlJvY2tlci54ID0gMDtcclxuICAgICAgICB0aGlzLlJvY2tlci55ID0gMDtcclxuICAgICAgICB0aGlzLmRpciA9IGNjLnYyKDAsMCk7XHJcblxyXG4gICAgICAgIHRoaXMuUm9ja2VyLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULGZ1bmN0aW9uKGUpe1xyXG4gICAgICAgICAgICB2YXIgd19wb3MgPSBlLmdldExvY2F0aW9uKCk7XHJcbiAgICAgICAgICAgdmFyIHBvcyA9IHRoaXMubm9kZS5jb252ZXJ0VG9Ob2RlU3BhY2VBUih3X3Bvcyk7Ly/lsIbkuJbnlYzlnZDmoIfovazljJbkuLrniLboioLngrnnmoTnm7jlr7nlnZDmoIdcclxuXHJcbiAgICAgICAgICAgIHZhciBsZW4gPSBwb3MubWFnKCk7XHJcbiAgICAgICAgICAgIHRoaXMuZGlyLnggPSBwb3MueCAvIGxlbjtcclxuICAgICAgICAgICAgdGhpcy5kaXIueSA9IHBvcy55IC8gbGVuO1xyXG4gICAgICAgICAgICBpZihsZW4gPiB0aGlzLk1heF9yKXtcclxuICAgICAgICAgICAgICAgIHBvcy54ID0gdGhpcy5NYXhfciAqIHBvcy54IC8gbGVuO1xyXG4gICAgICAgICAgICAgICAgcG9zLnkgPSB0aGlzLk1heF9yICogcG9zLnkgLyBsZW47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5Sb2NrZXIuc2V0UG9zaXRpb24ocG9zKTtcclxuICAgICAgICB9LHRoaXMpO1xyXG5cclxuICAgICAgICB0aGlzLlJvY2tlci5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLGZ1bmN0aW9uKGUpe1xyXG4gICAgICAgICAgIHZhciB3X3BvcyA9IGUuZ2V0TG9jYXRpb24oKTtcclxuICAgICAgICAgICB2YXIgcG9zID0gdGhpcy5ub2RlLmNvbnZlcnRUb05vZGVTcGFjZUFSKHdfcG9zKTsvL+WwhuS4lueVjOWdkOagh+i9rOWMluS4uueItuiKgueCueeahOebuOWvueWdkOagh1xyXG5cclxuXHJcbiAgICAgICAgICAgIHZhciBsZW4gPSBwb3MubWFnKCk7XHJcbiAgICAgICAgICAgIHRoaXMuZGlyLnggPSBwb3MueCAvIGxlbjtcclxuICAgICAgICAgICAgdGhpcy5kaXIueSA9IHBvcy55IC8gbGVuO1xyXG4gICAgICAgICAgICBpZihsZW4gPiB0aGlzLk1heF9yKXtcclxuICAgICAgICAgICAgICAgIHBvcy54ID0gdGhpcy5NYXhfciAqIHBvcy54IC8gbGVuO1xyXG4gICAgICAgICAgICAgICAgcG9zLnkgPSB0aGlzLk1heF9yICogcG9zLnkgLyBsZW47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5Sb2NrZXIuc2V0UG9zaXRpb24ocG9zKTtcclxuICAgICAgICB9LHRoaXMpO1xyXG5cclxuICAgICAgICB0aGlzLlJvY2tlci5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsZnVuY3Rpb24oZSl7XHJcbiAgICAgICAgICAgdGhpcy5Sb2NrZXIuc2V0UG9zaXRpb24oY2MudjIoMCwwKSk7XHJcbiBcdFx0ICAgdGhpcy5kaXIgPSBjYy52MigwLCAwKTtcclxuICAgICAgICB9LHRoaXMpO1xyXG5cclxuICAgICAgICB0aGlzLlJvY2tlci5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9DQU5DRUwsZnVuY3Rpb24oZSl7XHJcbiAgICAgICAgICAgIHRoaXMuUm9ja2VyLnNldFBvc2l0aW9uKGNjLnYyKDAsMCkpO1xyXG4gXHRcdFx0dGhpcy5kaXIgPSBjYy52MigwLCAwKTtcclxuICAgICAgICB9LHRoaXMpO1xyXG4gICAgfSxcclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scipts/登录界面/button_game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c4a6abRw81DNZG/8/EL67lb', 'button_game');
// scipts/登录界面/button_game.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
//跳过服务器连接直接启动游戏
//是一个测试按钮的script
cc.Class({
  "extends": cc.Component,
  properties: {},
  btnClick1: function btnClick1(event, customEventData) {
    //这里 event 是一个 Touch Event 对象，你可以通过 event.target 取到事件的发送节点
    //这里的 customEventData 参数就等于你之前设置的 "click1 user data"
    cc.director.loadScene("game");
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NpcHRzXFznmbvlvZXnlYzpnaJcXGJ1dHRvbl9nYW1lLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiYnRuQ2xpY2sxIiwiZXZlbnQiLCJjdXN0b21FdmVudERhdGEiLCJkaXJlY3RvciIsImxvYWRTY2VuZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0xDLEVBQUFBLFNBQVMsRUFBRSxtQkFBVUMsS0FBVixFQUFpQkMsZUFBakIsRUFBa0M7QUFDekM7QUFDQTtBQUNBTixJQUFBQSxFQUFFLENBQUNPLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixNQUF0QjtBQUNILEdBWEksQ0FZTDs7QUFaSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbi8v6Lez6L+H5pyN5Yqh5Zmo6L+e5o6l55u05o6l5ZCv5Yqo5ri45oiPXHJcbi8v5piv5LiA5Liq5rWL6K+V5oyJ6ZKu55qEc2NyaXB0XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBidG5DbGljazE6IGZ1bmN0aW9uIChldmVudCwgY3VzdG9tRXZlbnREYXRhKSB7XHJcbiAgICAgICAgLy/ov5nph4wgZXZlbnQg5piv5LiA5LiqIFRvdWNoIEV2ZW50IOWvueixoe+8jOS9oOWPr+S7pemAmui/hyBldmVudC50YXJnZXQg5Y+W5Yiw5LqL5Lu255qE5Y+R6YCB6IqC54K5XHJcbiAgICAgICAgLy/ov5nph4znmoQgY3VzdG9tRXZlbnREYXRhIOWPguaVsOWwseetieS6juS9oOS5i+WJjeiuvue9rueahCBcImNsaWNrMSB1c2VyIGRhdGFcIlxyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcImdhbWVcIik7XHJcbiAgICB9XHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

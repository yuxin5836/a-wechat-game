
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scipts/登录界面/button_login.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '26024PnwLJO4qKFMqjiWxM4', 'button_login');
// scipts/登录界面/button_login.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
//如果加上了window就相当于声明成了全局变量
window.user_name;
window.user_code;
window.websocket;
var flag_login = 0; //标志变量,告诉客户端是否登录成功
//0失败,1成功

var flag_register = 0; //是否注册成功(如果有重复的用户名将会注册失败)

cc.Class({
  "extends": cc.Component,
  properties: {},
  start: function start() {
    this.initSocket();
  },
  btnClick2: function btnClick2(event, customEventData) {
    user_name = this.node.getChildByName("user_input").getComponent(cc.EditBox).string;
    user_code = this.node.getChildByName("code_input").getComponent(cc.EditBox).string; //websocket.send(user_name.toString()+" "+user_code.toString());

    cc.log(user_name);
    cc.log(user_code);
  }
  /*
      //初始化与服务器建立连接
      initSocket: function(){
          if(window.WebSocket){
              var wsUri = "ws://localhost:8080/tomcat_websocket/test";
              websocket = new WebSocket(wsUri);
              //websocket.binaryType = "arraybuffer";
              //var mythis = this;
              //连接到服务器后执行
              websocket.onopen = function(event) {
                  console.log("connect");
                  //mythis.requestInitInfoBar();
              };
      
              //断开服务器连接后执行
              websocket.onclose = function(event) {
                  console.log("closed");
              };
      
              //接收服务器传递的消息后执行
              websocket.onmessage = function(event) {
                  if(event.data.substr(0,2)=='id')
                      cc.log(event.data);
                  //mythis.processData(json);
              };
              //报错时执行
              websocket.onerror = function(event) {
                  console.log("error");
              };
              }
              else{
                  alert("浏览器不支持WebSocket！");
              }
          }
          */

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NpcHRzXFznmbvlvZXnlYzpnaJcXGJ1dHRvbl9sb2dpbi5qcyJdLCJuYW1lcyI6WyJ3aW5kb3ciLCJ1c2VyX25hbWUiLCJ1c2VyX2NvZGUiLCJ3ZWJzb2NrZXQiLCJmbGFnX2xvZ2luIiwiZmxhZ19yZWdpc3RlciIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3RhcnQiLCJpbml0U29ja2V0IiwiYnRuQ2xpY2syIiwiZXZlbnQiLCJjdXN0b21FdmVudERhdGEiLCJub2RlIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJFZGl0Qm94Iiwic3RyaW5nIiwibG9nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0FBLE1BQU0sQ0FBQ0MsU0FBUDtBQUNBRCxNQUFNLENBQUNFLFNBQVA7QUFDQUYsTUFBTSxDQUFDRyxTQUFQO0FBRUEsSUFBSUMsVUFBVSxHQUFDLENBQWYsRUFDQTtBQUNBOztBQUVBLElBQUlDLGFBQWEsR0FBQyxDQUFsQixFQUNBOztBQUVBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsRUFIUDtBQU1MQyxFQUFBQSxLQU5LLG1CQU1FO0FBQ0gsU0FBS0MsVUFBTDtBQUNILEdBUkk7QUFTTEMsRUFBQUEsU0FBUyxFQUFFLG1CQUFVQyxLQUFWLEVBQWlCQyxlQUFqQixFQUFpQztBQUN4Q2IsSUFBQUEsU0FBUyxHQUFDLEtBQUtjLElBQUwsQ0FBVUMsY0FBVixDQUF5QixZQUF6QixFQUF1Q0MsWUFBdkMsQ0FBb0RYLEVBQUUsQ0FBQ1ksT0FBdkQsRUFBZ0VDLE1BQTFFO0FBQ0FqQixJQUFBQSxTQUFTLEdBQUMsS0FBS2EsSUFBTCxDQUFVQyxjQUFWLENBQXlCLFlBQXpCLEVBQXVDQyxZQUF2QyxDQUFvRFgsRUFBRSxDQUFDWSxPQUF2RCxFQUFnRUMsTUFBMUUsQ0FGd0MsQ0FHeEM7O0FBQ0FiLElBQUFBLEVBQUUsQ0FBQ2MsR0FBSCxDQUFPbkIsU0FBUDtBQUNBSyxJQUFBQSxFQUFFLENBQUNjLEdBQUgsQ0FBT2xCLFNBQVA7QUFDSDtBQUdEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5cclxuXHJcbi8v5aaC5p6c5Yqg5LiK5LqGd2luZG935bCx55u45b2T5LqO5aOw5piO5oiQ5LqG5YWo5bGA5Y+Y6YePXHJcbndpbmRvdy51c2VyX25hbWU7XHJcbndpbmRvdy51c2VyX2NvZGU7XHJcbndpbmRvdy53ZWJzb2NrZXQ7XHJcblxyXG52YXIgZmxhZ19sb2dpbj0wO1xyXG4vL+agh+W/l+WPmOmHjyzlkYror4nlrqLmiLfnq6/mmK/lkKbnmbvlvZXmiJDlip9cclxuLy8w5aSx6LSlLDHmiJDlip9cclxuXHJcbnZhciBmbGFnX3JlZ2lzdGVyPTA7XHJcbi8v5piv5ZCm5rOo5YaM5oiQ5YqfKOWmguaenOaciemHjeWkjeeahOeUqOaIt+WQjeWwhuS8muazqOWGjOWksei0pSlcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0KCl7XHJcbiAgICAgICAgdGhpcy5pbml0U29ja2V0KCk7XHJcbiAgICB9LFxyXG4gICAgYnRuQ2xpY2syOiBmdW5jdGlvbiAoZXZlbnQsIGN1c3RvbUV2ZW50RGF0YSl7XHJcbiAgICAgICAgdXNlcl9uYW1lPXRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcInVzZXJfaW5wdXRcIikuZ2V0Q29tcG9uZW50KGNjLkVkaXRCb3gpLnN0cmluZztcclxuICAgICAgICB1c2VyX2NvZGU9dGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiY29kZV9pbnB1dFwiKS5nZXRDb21wb25lbnQoY2MuRWRpdEJveCkuc3RyaW5nO1xyXG4gICAgICAgIC8vd2Vic29ja2V0LnNlbmQodXNlcl9uYW1lLnRvU3RyaW5nKCkrXCIgXCIrdXNlcl9jb2RlLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgIGNjLmxvZyh1c2VyX25hbWUpO1xyXG4gICAgICAgIGNjLmxvZyh1c2VyX2NvZGUpO1xyXG4gICAgfSxcclxuXHJcblxyXG4gICAgLypcclxuICAgICAgICAvL+WIneWni+WMluS4juacjeWKoeWZqOW7uueri+i/nuaOpVxyXG4gICAgICAgIGluaXRTb2NrZXQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIGlmKHdpbmRvdy5XZWJTb2NrZXQpe1xyXG4gICAgICAgICAgICAgICAgdmFyIHdzVXJpID0gXCJ3czovL2xvY2FsaG9zdDo4MDgwL3RvbWNhdF93ZWJzb2NrZXQvdGVzdFwiO1xyXG4gICAgICAgICAgICAgICAgd2Vic29ja2V0ID0gbmV3IFdlYlNvY2tldCh3c1VyaSk7XHJcbiAgICAgICAgICAgICAgICAvL3dlYnNvY2tldC5iaW5hcnlUeXBlID0gXCJhcnJheWJ1ZmZlclwiO1xyXG4gICAgICAgICAgICAgICAgLy92YXIgbXl0aGlzID0gdGhpcztcclxuICAgICAgICAgICAgICAgIC8v6L+e5o6l5Yiw5pyN5Yqh5Zmo5ZCO5omn6KGMXHJcbiAgICAgICAgICAgICAgICB3ZWJzb2NrZXQub25vcGVuID0gZnVuY3Rpb24oZXZlbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImNvbm5lY3RcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9teXRoaXMucmVxdWVzdEluaXRJbmZvQmFyKCk7XHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgIFxyXG4gICAgICAgICAgICAgICAgLy/mlq3lvIDmnI3liqHlmajov57mjqXlkI7miafooYxcclxuICAgICAgICAgICAgICAgIHdlYnNvY2tldC5vbmNsb3NlID0gZnVuY3Rpb24oZXZlbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImNsb3NlZFwiKTtcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAvL+aOpeaUtuacjeWKoeWZqOS8oOmAkueahOa2iOaBr+WQjuaJp+ihjFxyXG4gICAgICAgICAgICAgICAgd2Vic29ja2V0Lm9ubWVzc2FnZSA9IGZ1bmN0aW9uKGV2ZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoZXZlbnQuZGF0YS5zdWJzdHIoMCwyKT09J2lkJylcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2MubG9nKGV2ZW50LmRhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vbXl0aGlzLnByb2Nlc3NEYXRhKGpzb24pO1xyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIC8v5oql6ZSZ5pe25omn6KGMXHJcbiAgICAgICAgICAgICAgICB3ZWJzb2NrZXQub25lcnJvciA9IGZ1bmN0aW9uKGV2ZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlcnJvclwiKTtcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICAgICAgICAgIGFsZXJ0KFwi5rWP6KeI5Zmo5LiN5pSv5oyBV2ViU29ja2V077yBXCIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICovXHJcblxyXG59KTtcclxuIl19
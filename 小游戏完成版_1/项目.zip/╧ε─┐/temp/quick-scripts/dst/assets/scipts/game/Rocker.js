
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scipts/game/Rocker.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '28d7ef5RfFC7pvGiaBD0KJG', 'Rocker');
// scipts/game/Rocker.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    Rocker: {
      type: cc.Node,
      "default": null
    },
    Max_r: 100
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.Rocker.x = 0;
    this.Rocker.y = 0;
    this.dir = cc.v2(0, 0);
    this.Rocker.on(cc.Node.EventType.TOUCH_START, function (e) {
      var w_pos = e.getLocation();
      var pos = this.node.convertToNodeSpaceAR(w_pos); //将世界坐标转化为父节点的相对坐标

      var len = pos.mag();
      this.dir.x = pos.x / len;
      this.dir.y = pos.y / len;

      if (len > this.Max_r) {
        pos.x = this.Max_r * pos.x / len;
        pos.y = this.Max_r * pos.y / len;
      }

      this.Rocker.setPosition(pos);
    }, this);
    this.Rocker.on(cc.Node.EventType.TOUCH_MOVE, function (e) {
      var w_pos = e.getLocation();
      var pos = this.node.convertToNodeSpaceAR(w_pos); //将世界坐标转化为父节点的相对坐标

      var len = pos.mag();
      this.dir.x = pos.x / len;
      this.dir.y = pos.y / len;

      if (len > this.Max_r) {
        pos.x = this.Max_r * pos.x / len;
        pos.y = this.Max_r * pos.y / len;
      }

      this.Rocker.setPosition(pos);
    }, this);
    this.Rocker.on(cc.Node.EventType.TOUCH_END, function (e) {
      this.Rocker.setPosition(cc.v2(0, 0));
      this.dir = cc.v2(0, 0);
    }, this);
    this.Rocker.on(cc.Node.EventType.TOUCH_CANCEL, function (e) {
      this.Rocker.setPosition(cc.v2(0, 0));
      this.dir = cc.v2(0, 0);
    }, this);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NpcHRzXFxnYW1lXFxSb2NrZXIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJSb2NrZXIiLCJ0eXBlIiwiTm9kZSIsIk1heF9yIiwic3RhcnQiLCJ4IiwieSIsImRpciIsInYyIiwib24iLCJFdmVudFR5cGUiLCJUT1VDSF9TVEFSVCIsImUiLCJ3X3BvcyIsImdldExvY2F0aW9uIiwicG9zIiwibm9kZSIsImNvbnZlcnRUb05vZGVTcGFjZUFSIiwibGVuIiwibWFnIiwic2V0UG9zaXRpb24iLCJUT1VDSF9NT1ZFIiwiVE9VQ0hfRU5EIiwiVE9VQ0hfQ0FOQ0VMIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFHUkMsSUFBQUEsTUFBTSxFQUFDO0FBQ0hDLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDTSxJQURMO0FBRUgsaUJBQVE7QUFGTCxLQUhDO0FBUVJDLElBQUFBLEtBQUssRUFBQztBQVJFLEdBSFA7QUFjTDtBQUVBO0FBRUFDLEVBQUFBLEtBbEJLLG1CQWtCSTtBQUNMLFNBQUtKLE1BQUwsQ0FBWUssQ0FBWixHQUFnQixDQUFoQjtBQUNBLFNBQUtMLE1BQUwsQ0FBWU0sQ0FBWixHQUFnQixDQUFoQjtBQUNBLFNBQUtDLEdBQUwsR0FBV1gsRUFBRSxDQUFDWSxFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBWDtBQUVBLFNBQUtSLE1BQUwsQ0FBWVMsRUFBWixDQUFlYixFQUFFLENBQUNNLElBQUgsQ0FBUVEsU0FBUixDQUFrQkMsV0FBakMsRUFBNkMsVUFBU0MsQ0FBVCxFQUFXO0FBQ3BELFVBQUlDLEtBQUssR0FBR0QsQ0FBQyxDQUFDRSxXQUFGLEVBQVo7QUFDRCxVQUFJQyxHQUFHLEdBQUcsS0FBS0MsSUFBTCxDQUFVQyxvQkFBVixDQUErQkosS0FBL0IsQ0FBVixDQUZxRCxDQUVMOztBQUUvQyxVQUFJSyxHQUFHLEdBQUdILEdBQUcsQ0FBQ0ksR0FBSixFQUFWO0FBQ0EsV0FBS1osR0FBTCxDQUFTRixDQUFULEdBQWFVLEdBQUcsQ0FBQ1YsQ0FBSixHQUFRYSxHQUFyQjtBQUNBLFdBQUtYLEdBQUwsQ0FBU0QsQ0FBVCxHQUFhUyxHQUFHLENBQUNULENBQUosR0FBUVksR0FBckI7O0FBQ0EsVUFBR0EsR0FBRyxHQUFHLEtBQUtmLEtBQWQsRUFBb0I7QUFDaEJZLFFBQUFBLEdBQUcsQ0FBQ1YsQ0FBSixHQUFRLEtBQUtGLEtBQUwsR0FBYVksR0FBRyxDQUFDVixDQUFqQixHQUFxQmEsR0FBN0I7QUFDQUgsUUFBQUEsR0FBRyxDQUFDVCxDQUFKLEdBQVEsS0FBS0gsS0FBTCxHQUFhWSxHQUFHLENBQUNULENBQWpCLEdBQXFCWSxHQUE3QjtBQUNIOztBQUNELFdBQUtsQixNQUFMLENBQVlvQixXQUFaLENBQXdCTCxHQUF4QjtBQUNILEtBWkQsRUFZRSxJQVpGO0FBY0EsU0FBS2YsTUFBTCxDQUFZUyxFQUFaLENBQWViLEVBQUUsQ0FBQ00sSUFBSCxDQUFRUSxTQUFSLENBQWtCVyxVQUFqQyxFQUE0QyxVQUFTVCxDQUFULEVBQVc7QUFDcEQsVUFBSUMsS0FBSyxHQUFHRCxDQUFDLENBQUNFLFdBQUYsRUFBWjtBQUNBLFVBQUlDLEdBQUcsR0FBRyxLQUFLQyxJQUFMLENBQVVDLG9CQUFWLENBQStCSixLQUEvQixDQUFWLENBRm9ELENBRUo7O0FBRy9DLFVBQUlLLEdBQUcsR0FBR0gsR0FBRyxDQUFDSSxHQUFKLEVBQVY7QUFDQSxXQUFLWixHQUFMLENBQVNGLENBQVQsR0FBYVUsR0FBRyxDQUFDVixDQUFKLEdBQVFhLEdBQXJCO0FBQ0EsV0FBS1gsR0FBTCxDQUFTRCxDQUFULEdBQWFTLEdBQUcsQ0FBQ1QsQ0FBSixHQUFRWSxHQUFyQjs7QUFDQSxVQUFHQSxHQUFHLEdBQUcsS0FBS2YsS0FBZCxFQUFvQjtBQUNoQlksUUFBQUEsR0FBRyxDQUFDVixDQUFKLEdBQVEsS0FBS0YsS0FBTCxHQUFhWSxHQUFHLENBQUNWLENBQWpCLEdBQXFCYSxHQUE3QjtBQUNBSCxRQUFBQSxHQUFHLENBQUNULENBQUosR0FBUSxLQUFLSCxLQUFMLEdBQWFZLEdBQUcsQ0FBQ1QsQ0FBakIsR0FBcUJZLEdBQTdCO0FBQ0g7O0FBQ0QsV0FBS2xCLE1BQUwsQ0FBWW9CLFdBQVosQ0FBd0JMLEdBQXhCO0FBQ0gsS0FiRCxFQWFFLElBYkY7QUFlQSxTQUFLZixNQUFMLENBQVlTLEVBQVosQ0FBZWIsRUFBRSxDQUFDTSxJQUFILENBQVFRLFNBQVIsQ0FBa0JZLFNBQWpDLEVBQTJDLFVBQVNWLENBQVQsRUFBVztBQUNuRCxXQUFLWixNQUFMLENBQVlvQixXQUFaLENBQXdCeEIsRUFBRSxDQUFDWSxFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBeEI7QUFDTCxXQUFLRCxHQUFMLEdBQVdYLEVBQUUsQ0FBQ1ksRUFBSCxDQUFNLENBQU4sRUFBUyxDQUFULENBQVg7QUFDRyxLQUhELEVBR0UsSUFIRjtBQUtBLFNBQUtSLE1BQUwsQ0FBWVMsRUFBWixDQUFlYixFQUFFLENBQUNNLElBQUgsQ0FBUVEsU0FBUixDQUFrQmEsWUFBakMsRUFBOEMsVUFBU1gsQ0FBVCxFQUFXO0FBQ3JELFdBQUtaLE1BQUwsQ0FBWW9CLFdBQVosQ0FBd0J4QixFQUFFLENBQUNZLEVBQUgsQ0FBTSxDQUFOLEVBQVEsQ0FBUixDQUF4QjtBQUNSLFdBQUtELEdBQUwsR0FBV1gsRUFBRSxDQUFDWSxFQUFILENBQU0sQ0FBTixFQUFTLENBQVQsQ0FBWDtBQUNLLEtBSEQsRUFHRSxJQUhGO0FBSUgsR0E3REksQ0E4REw7O0FBOURLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHJcblxyXG4gICAgICAgIFJvY2tlcjp7XHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIE1heF9yOjEwMCxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICB0aGlzLlJvY2tlci54ID0gMDtcclxuICAgICAgICB0aGlzLlJvY2tlci55ID0gMDtcclxuICAgICAgICB0aGlzLmRpciA9IGNjLnYyKDAsMCk7XHJcblxyXG4gICAgICAgIHRoaXMuUm9ja2VyLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULGZ1bmN0aW9uKGUpe1xyXG4gICAgICAgICAgICB2YXIgd19wb3MgPSBlLmdldExvY2F0aW9uKCk7XHJcbiAgICAgICAgICAgdmFyIHBvcyA9IHRoaXMubm9kZS5jb252ZXJ0VG9Ob2RlU3BhY2VBUih3X3Bvcyk7Ly/lsIbkuJbnlYzlnZDmoIfovazljJbkuLrniLboioLngrnnmoTnm7jlr7nlnZDmoIdcclxuXHJcbiAgICAgICAgICAgIHZhciBsZW4gPSBwb3MubWFnKCk7XHJcbiAgICAgICAgICAgIHRoaXMuZGlyLnggPSBwb3MueCAvIGxlbjtcclxuICAgICAgICAgICAgdGhpcy5kaXIueSA9IHBvcy55IC8gbGVuO1xyXG4gICAgICAgICAgICBpZihsZW4gPiB0aGlzLk1heF9yKXtcclxuICAgICAgICAgICAgICAgIHBvcy54ID0gdGhpcy5NYXhfciAqIHBvcy54IC8gbGVuO1xyXG4gICAgICAgICAgICAgICAgcG9zLnkgPSB0aGlzLk1heF9yICogcG9zLnkgLyBsZW47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5Sb2NrZXIuc2V0UG9zaXRpb24ocG9zKTtcclxuICAgICAgICB9LHRoaXMpO1xyXG5cclxuICAgICAgICB0aGlzLlJvY2tlci5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLGZ1bmN0aW9uKGUpe1xyXG4gICAgICAgICAgIHZhciB3X3BvcyA9IGUuZ2V0TG9jYXRpb24oKTtcclxuICAgICAgICAgICB2YXIgcG9zID0gdGhpcy5ub2RlLmNvbnZlcnRUb05vZGVTcGFjZUFSKHdfcG9zKTsvL+WwhuS4lueVjOWdkOagh+i9rOWMluS4uueItuiKgueCueeahOebuOWvueWdkOagh1xyXG5cclxuXHJcbiAgICAgICAgICAgIHZhciBsZW4gPSBwb3MubWFnKCk7XHJcbiAgICAgICAgICAgIHRoaXMuZGlyLnggPSBwb3MueCAvIGxlbjtcclxuICAgICAgICAgICAgdGhpcy5kaXIueSA9IHBvcy55IC8gbGVuO1xyXG4gICAgICAgICAgICBpZihsZW4gPiB0aGlzLk1heF9yKXtcclxuICAgICAgICAgICAgICAgIHBvcy54ID0gdGhpcy5NYXhfciAqIHBvcy54IC8gbGVuO1xyXG4gICAgICAgICAgICAgICAgcG9zLnkgPSB0aGlzLk1heF9yICogcG9zLnkgLyBsZW47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5Sb2NrZXIuc2V0UG9zaXRpb24ocG9zKTtcclxuICAgICAgICB9LHRoaXMpO1xyXG5cclxuICAgICAgICB0aGlzLlJvY2tlci5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsZnVuY3Rpb24oZSl7XHJcbiAgICAgICAgICAgdGhpcy5Sb2NrZXIuc2V0UG9zaXRpb24oY2MudjIoMCwwKSk7XHJcbiBcdFx0ICAgdGhpcy5kaXIgPSBjYy52MigwLCAwKTtcclxuICAgICAgICB9LHRoaXMpO1xyXG5cclxuICAgICAgICB0aGlzLlJvY2tlci5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9DQU5DRUwsZnVuY3Rpb24oZSl7XHJcbiAgICAgICAgICAgIHRoaXMuUm9ja2VyLnNldFBvc2l0aW9uKGNjLnYyKDAsMCkpO1xyXG4gXHRcdFx0dGhpcy5kaXIgPSBjYy52MigwLCAwKTtcclxuICAgICAgICB9LHRoaXMpO1xyXG4gICAgfSxcclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
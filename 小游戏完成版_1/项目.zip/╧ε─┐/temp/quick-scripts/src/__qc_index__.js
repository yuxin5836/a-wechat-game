
require('./assets/scipts/game/Rocker');
require('./assets/scipts/game/map');
require('./assets/scipts/登录界面/button_game');
require('./assets/scipts/登录界面/button_login');
